/**  
 *  
 * @author Okay Tonka okay.tonka@ogr.sakarya.edu.tr  
 * @since 04 Nisan 2019 Perşembe
 * <p>  
 *  Rastgele karakter oluşturma ve kalıtım alma 
 * </p>  
 */ 
#include <stdio.h>
#include <stdlib.h>
#include "Random.h"
#include <stdarg.h>

int R_Gele;

char Rastgele_Karakter_Olustur() {
    char karakter;

    while (1) {
        R_Gele = (int) ((Zaman()) % 123);
        if ((R_Gele >= 65 && R_Gele <= 90) || (R_Gele >= 97 && R_Gele <= 122)) {
            break;
        }

    }

    karakter = (char) R_Gele;
    return karakter;
}

void Adetli_Rastgele_Karakter_Olustur(int kacadet) {
    char kadet[kacadet];
    for (int y = 1; y <= kacadet; y++) {

        R_Gele = Rastgele_Karakter_Olustur();
        kadet [y - 1] = (char) R_Gele;
    }
    printf("Rastgele Adetli Karakter: %s\n", kadet);

}

char Iki_Karakter_Arasinda_Rastgele_Olustur(int a, int karakter) {

    do {
        R_Gele = Rastgele_Karakter_Olustur();
        if (R_Gele >= a && R_Gele <= karakter) {
            break;
        }
    } while (1);

    return (char) R_Gele;

}

void Iki_Karakter_Arasinda_Adet_Kadar(int a, int karakter, int p) {
    char kadet[p];



    for (int y = 1; y <= p; y++) {
        do {
            R_Gele = Rastgele_Karakter_Olustur();
            if (R_Gele >= a && R_Gele <= karakter) {


                break;
            }

        } while (1);


        kadet [y - 1] = (char) R_Gele;
    }
    printf("Verilen Iki Karakter Arasinda Adet Kadar: %s\n", kadet);


}

void Belirli_Karakterler_Arasinda_Rastgele_Karakter_Olustur(int karakter_araligi, ...) {
    char cmle[karakter_araligi];
    char cmle2[karakter_araligi];

    int y = 0;



    va_list valst;

    va_start(valst, karakter_araligi);

    int n = 0;

    for (int i = 0; i < karakter_araligi; i++) {
        cmle2[i] = va_arg(valst, int);


    }
    int a = Zaman() % karakter_araligi;
    printf("Belirtilen Karakterler Arasinda: %c\n", (char) cmle2[a]);

    va_end(valst);
}

void Belirli_Karakterler_Arasinda_Belirli_Sayida_Rastgele_Karakter_Olustur(int adet, int karakter_araligi, ...) {
    char cmle[karakter_araligi];
    char cmle2[karakter_araligi];

    int y = 0;



    va_list valst;

    va_start(valst, karakter_araligi);

    int n = 0;

    for (int i = 0; i < karakter_araligi; i++) {
        cmle2[i] = va_arg(valst, int);
        // printf("%c",(char)cmle2[i]);

    }
    for (int i = 0; i <= adet - 1; i++) {
        int a = Zaman() % (karakter_araligi);
        // printf("%i",a);
        cmle[i] = cmle2[a];

    }

    printf("Belirtilen Karakterler Arasinda Adet Kadar: %s\n", cmle);

    va_end(valst);
}

void Cumle_Olustur(int bslk) {


    int bos;

    char Cumle_Olustur[bslk + 35];
    char cumle2[bslk + 35];

    for (int y = 0; y < bslk + 35; y++) {

        Cumle_Olustur[y] = Rastgele_Karakter_Olustur();
    }



    for (int y = 0; y < bslk + 35; y++) {
        cumle2[y] = Cumle_Olustur[y];
        if (bslk != 0) {
            bos = (int) ((Zaman()) % 35);
            cumle2[bos] = ' ';
            bslk--;
        }

    }
    printf("Cumle: %s", Cumle_Olustur);

}
