/**  
 *  
 * @author Okay Tonka okay.tonka@ogr.sakarya.edu.tr  
 * @since 04 Nisan 2019 Perşembe
 * <p>  
 *  Rastgele karakter oluşturma ve kalıtım alma 
 * </p>  
 */ 

#ifndef RANDOM_H
#define RANDOM_H

#ifdef __cplusplus
extern "C" {
#endif


    int Zaman();

#ifdef __cplusplus
}
#endif

#endif /* RANDOM_H */

