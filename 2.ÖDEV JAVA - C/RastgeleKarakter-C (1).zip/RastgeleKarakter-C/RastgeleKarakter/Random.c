/**  
 *  
 * @author Okay Tonka okay.tonka@ogr.sakarya.edu.tr  
 * @since 04 Nisan 2019 Perşembe
 * <p>  
 *  Rastgele karakter oluşturma ve kalıtım alma 
 * </p>  
 */ 

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Random.h"


int Zaman() {
    int zaman;


    zaman = rand();

    return zaman;
}

