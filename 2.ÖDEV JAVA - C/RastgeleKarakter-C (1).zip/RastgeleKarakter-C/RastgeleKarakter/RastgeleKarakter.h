/**  
 *  
 * @author Okay Tonka okay.tonka@ogr.sakarya.edu.tr  
 * @since 04 Nisan 2019 Perşembe
 * <p>  
 *  Rastgele karakter oluşturma ve kalıtım alma 
 * </p>  
 */ 

#ifndef RASTGELEKARAKTER_H
#define RASTGELEKARAKTER_H

#ifdef __cplusplus
extern "C" {
#endif

    char Rastgele_Karakter_Olustur();
    void Adetli_Rastgele_Karakter_Olustur(int kacadet);
    char Iki_Karakter_Arasinda_Rastgele_Olustur(int a, int karakter);
    void Iki_Karakter_Arasinda_Adet_Kadar(int a, int karakter, int p);
    void Belirli_Karakterler_Arasinda_Rastgele_Karakter_Olustur(int karakter_araligi, ...);
    void Belirli_Karakterler_Arasinda_Belirli_Sayida_Rastgele_Karakter_Olustur(int adet, int karakter_araligi, ...);
    void Cumle_Olustur(int bslk);


#ifdef __cplusplus
}
#endif

#endif /* RASTGELEKARAKTER_H */

