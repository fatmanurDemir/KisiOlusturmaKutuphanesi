/**  
 *  
 * @author Okay Tonka okay.tonka@ogr.sakarya.edu.tr  
 * @since 04 Nisan 2019 Perşembe
 * <p>  
 *  Rastgele karakter oluşturma ve kalıtım alma 
 * </p>  
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "RastgeleKarakter.h"

/*
 * 
 */
int main(int argc, char** argv) {
    srand(time(NULL));


    printf("Rastgele Karakter: %c\n", Rastgele_Karakter_Olustur());
    printf("Rastgele Karakter: %c\n", Rastgele_Karakter_Olustur());

    Adetli_Rastgele_Karakter_Olustur(3);
    Adetli_Rastgele_Karakter_Olustur(3);

    printf("Verilen Iki Karakter Arasinda: %c\n", Iki_Karakter_Arasinda_Rastgele_Olustur('a', 'k'));

    Iki_Karakter_Arasinda_Adet_Kadar('a', 'k', 15);
    Belirli_Karakterler_Arasinda_Rastgele_Karakter_Olustur(5, 'b', 'e', 't', 'g', 'H');
    Belirli_Karakterler_Arasinda_Rastgele_Karakter_Olustur(5, 'b', 'e', 't', 'g', 'H');
    //5 Rakamı sonrasında kaç adet veri gönderileceğini belirler ve valist kullanımına imkan sağlar.
    Belirli_Karakterler_Arasinda_Belirli_Sayida_Rastgele_Karakter_Olustur(7, 5, 'b', 'e', 't', 'g', 'h');
    //5 Rakamı sonrasında kaç adet veri gönderileceğini belirler ve valist kullanımına imkan sağlar.
    //3 Rakamı ise karakterler arasında kaç tane harf seçilmesi ve random kelime oluşturulması gerektiğini belirtir.

    Cumle_Olustur(0);







    return 0;

    return (EXIT_SUCCESS);
}

